package com.example.demo;

import lombok.AllArgsConstructor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.RewritePathGatewayFilterFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}


	@Component
	@Primary
	@AllArgsConstructor // Lombok
	public static class ContextPathRewritePathGatewayFilterFactory extends RewritePathGatewayFilterFactory {
		private final RewritePathGatewayFilterFactory rewritePathGatewayFilterFactory;

		@Override
		public GatewayFilter apply(final RewritePathGatewayFilterFactory.Config config)
		{
			GatewayFilter delegate = rewritePathGatewayFilterFactory.apply(config);
			return (exchange, chain) -> {
				final ServerHttpRequest request = exchange.getRequest().mutate().contextPath("/").build();
				return delegate.filter(exchange.mutate().request(request).build(), chain);
			};
		}
	}
}
